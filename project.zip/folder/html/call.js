let obj1={
    name:'karthi',
    age:21,
    details: function(city,country){
        return this.name +" " +this.age +" "+city+" "+ country
    }
}
let obj2={
    name:"XZZ",
    age:23, 

}
// console.log(obj1.details.call(obj1,"banglore"));
console.log(obj1.details.apply(obj1,["banglore","India"]));