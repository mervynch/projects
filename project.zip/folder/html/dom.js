console.log("Welcome to js");


// let a =document.getElementById("dome")
// console.log(a);

// a.innerText="PYTHON"// to manipulate text

// a.style.cssText="color: red;background-color : yellow; font-size : 200px"


// a.style.color="white"

//using function targeting and changing 
// function change(){
//     let b=document.getElementById("dome")
//     b.style.cssText="color:red;background-color:yellow;"
//     b.innerText="PYSPIDERS"
// }


//eventListener
// btn.addEventListener("click",()=>{

//     a.style.cssText="color: red;background-color : yellow; font-size : 200px"
//     a.style.color="white"
//     a.innerText="HI"
// })


//by class name

// let c=document.getElementsByClassName('p')[0];
// c.innerText="hiiiiiiiiiiiiiiiiiiiiiiiii"

// let d=document.getElementsByClassName('p')[1];
// d.innerHTML="<p>this classname</p>"
// console.log(d);

//to change using loop
function change(){
    let items=document.getElementsByClassName("p")
    console.log(items);
    
//     for(let i=0;i<items.length;i++) {
//      items[i].style.color="red"
//      items[i].style.backgroundColor="yellow"
//         }
// }


// araylikeobjects to array we have 2 method from and Object.entries
// to use for each we have convert it into array it is not arraylikeobjects(para)
Array.from(items).forEach(ele=>{
    ele.style.color="green"
});

}

// let f =document.getElementsByTagName("h1")[1]
// f.style.cssText="color:red;background-color:yellow;"

function f(){
    let f =document.getElementsByTagName("h1")[1]
    // f.style.cssText="color:red;background-Color:yellow;"
    for (let i=0;i< f.length;i++){
        f[i].style.cssText="color:green; background-Color:red;"
    }
}
