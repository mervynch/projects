console.log(window.document);
console.log(screen);
console.log(navigator);
console.log(history);
console.log(location);



// console.log(window.screen.height);
// console.log(window.screen.colorDepth);

// console.log(window.navigator.onLine);
// console.log(navigator.language);
// console.log(history.length);
// console.log(history.back());

// console.log(history.go(1));
// console.log(navigation.reload());
// console.log(window.location.href);


// bom objects
// let p = prompt("enter your age");
// console.log(p);


// alert("your laptop is hacked");

// let c =confirm("enter your password")
// console.log(c);

// open("https:/www./filkcart.com");
// close()


console.log("start");
let time= setTimeout(()=>{
 console.log("hi"); 
},3000);

clearTimeout(time)

