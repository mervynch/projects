// if(true){
//     console.log("welcome");
// }




// if (1>10) {
//     console.log("thanku vist again");
// } 
// // else {
// //     console.log("hiiiii");    
// // }



// else if (1>10&&10==10) {
//     console.log("hiiii");
// }
// else{
//     console.log("finish");
// }
var a=10
// let b=20
// if(a==10){
//     if(b=20){
//         console.log("truuuuuuueeee");
// }
// }

switch(a){
    case 12:
        console.log("greater");
        break;
    case 10:
        console.log("smaller")
        break
    default:
        console.log(a)
        break
}

// ternary operator

let age=17;
let vote=(age>=18)?"can vote": "cannot vote";
console.log(vote)

let score=90;
let marks=(score>=80)?"grade A":(score<80)?"grade b":(score<70)?"grade c": "garde d";
console.log(marks)