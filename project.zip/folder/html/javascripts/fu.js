function demo(a,b){
    console.log (a+b);

}

demo(2,3)


// named function |^



// anonymons function
// function(){
//     console.log("welcome to js");
    
// }

// function expression LHS == RHS
let w=function(){
 console.log('this is function expression');
 console.log('this is first class function');
}
 w()


 let f=() =>{
    console.log('it is arrow function');
 }

 f()
 
var r=(e,s) =>e+s; //single line arrow function
 console.log(r(5,5))


 function calc(m,n,mervyn){
    return mervyn(m,n);
 }
 
function add(m,n){
    console.log(m+n);
    
}
function sub(m,n){
    console.log(m-n);
}
function mul(m,n){
    console.log(m*n);
    
}
calc(10,10,mul)
calc(10,5,sub)


function outer(){
    console.log("outter");
    function inner(){
        console.log("iam nested function");

    }
     return inner
}
outer()()


