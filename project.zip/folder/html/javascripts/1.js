var a=10;
console.log(a)

let b;
console.log(b)

const c=10;
console.log(c)
