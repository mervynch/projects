// (function (a,b)
// {
//     console.log(a+b);
    

// })(20,30)
 


// function outter(){
//     var a=10;
//     function inner(){
//         var b=20;
//         console.log(a+b);
        
//     }
//         return inner
// }
// outter()()


// genrator
// function* generat(n){
//     let a=1;
//     while(a<=4){
//         yield a;
//         a++;
//     }
// }
// let b=generat(10)
// console.log(b.next().value);
// console.log(b.next().value);
// console.log(b.next());
// console.log(b.next());








function* gloop(){
    yield 'helloo'
    yield 'world'
    yield 'hoe     .....................'
}

for (const value of gloop()){
    console.log(value);
}

function* infloop(){
let num=1;
 while(true){
    yield num;
    num++;
 }
}
let l=infloop()
console.log(l.next().value);
console.log(l.next().value);
console.log(l.next());


function* interactive(){
    let x=yield 'enter the values'
    yield `you have entered ${x}`;

}
let g=interactive()
console.log(g.next().value);
console.log(g.next(5).value);









