for (let i=2; i<=10; i+=2){
    console.log('these are even numbers',i);
    // console.log(i);
}

for (let a=0; a<=10; a+=1){
    if (a%2!==0){
       console.log('these are odd numbers',a);
        
    }
}
    
e=0
while(e<=10){
    console.log(e);

    e++
}

 