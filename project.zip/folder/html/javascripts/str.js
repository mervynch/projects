let a="    hiiii good morning      ";
let b='hellllooo';
 console.log(a.length);
 console.log(a.toUpperCase());
 console.log(a.toLowerCase());
 console.log(a.trimStart());
 console.log(a.trimEnd());
 console.log(a.trim());
 console.log(a.replace('good','bad'));
 console.log(a.replaceAll('morning','evening'));
 console.log(b.substring(0,3));
 console.log(b.includes('he'));
 console.log(b.includes('d'));
 console.log(b.concat('hii'));
 console.log(b.slice(3));
 console.log(b.indexOf('o'));
 console.log(a.split('good'));
 console.log(b.split('').reverse('').join(''));
 
 
 let arr=[10,20,30];

 console.log(arr);
 
 arr[2]=100;
 console.log(arr);
 

 let c =new Array(10,20,30,40,50);
 console.log(c);

 delete arr[0];
 console.log(arr);

 let arr1=[10,20,30,40,50];
//  console.log(arr1.slice(1,4));
console.log(arr1.splice(1,2,"karthik"));
console.log(arr1)


let arr5=[100,200,300,400,500]
arr5.pop()
console.log(arr5);

arr5.push(12) //adds elements
console.log(arr5);

arr5.shift() //removes first elements
console.log(arr5);

 arr5.unshift(50) //adds first elements
 console.log(arr5);

 
 arr5.reverse()
 console.log(arr5);


 console.log(Array.isArray(arr5));
 
 
 console.log(arr5.join('5'));
 

// let age=prompt('enter the values');
// if (age>=18){
//     console.log('can vote');
    
// }
// else{
//     console.log('cannot vote');
    
// }

let kar=[[1,2,3],
    [4,5,6,7],
    [8,9,10]]
for (const i of kar) {
    for (const j of i) {
        console.log(j);
        
    }
}


let fru=[["apple",'banno'],
    ['cherry','mango'],
['ornage','xyz']]
for (const n of fru) {
    for (const m of n) {
        console.log(m);
        
    }
    
}


let s='aditya'
for (const i of s) {
        console.log();
        
}

let sb='aditya'

for (const i of sb) {
    console.log(i);
    
    
}


let eg=[
    [1,2,3],
    [4,5,6],
    [7,8,9]
]

for (const i of eg) {

    for (const j of i) {
        console.log(j);
        
        
    }
    
}

//using for each

eg.forEach((value) => {
    value.forEach(v => {
        console.log(v);
        
        
    });
    
});

let fruits=[
    ['apple','bannana'],
    ['cherry','mango'],
    ['orange','xyz']
]

for (const fru of fruits) {

    for (const f of fru) {
        
        console.log(f);
        
    }
    
}

//using sort method

let s1=[50,40,7,10,60]

console.log(s1.sort((a,b)=>a-b));//- is used to sort the values syntax


 
 
 
 
 
 
 
 

 
 
 