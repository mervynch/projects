let arr=['hi','hello','cat','dog','world']
let res= console.log((arr.filter((a)=>a.length>3)));

let arr1=[-3,-5,-2,-1,0,1,50,1,2,3,4,60]
let re=console.log((arr1.filter((b)=>b>=1)));


let st=['apple','abc','hii','april']
let r=console.log((st.map((c)=>c.length<=3)));

let s=['apple','abc','adi','bobby','cat']
let o=console.log((s.filter((d)=>d.startsWith('a'))));

let d=['UPPER','HELLO','ikj']
let a=console.log((d.map((e)=>e.toUpperCase())));


let arr2=[1,2,3,4,5]
let f=console.log((arr2.reduce((a,b)=>a+b,10)));

// let arr3=[35,65,45,75,85,90]
// let m=console.log((arr3.reduce((g,s)=>(s<g)?g=g:g=s)));


let arr3=[35,65,45,75,85,90]
let m=console.log((arr3.reduce((g,s)=>(s<g)?g:s)));




 let obj={}
//  console.log(obj);

 obj.name='john';
 obj.age=25;
 obj.gender='male';
 obj.number=123456652
 
 console.log(obj);
 
//adding function 
obj.fun=function(){return('hello world');
}

console.log(obj.fun());

//using new keyword or construtor
let obj1=new Object()
console.log(obj1);


obj1.name='rahul';
obj1.age=23;
obj1.gender='male';
obj1.job='HR';
obj1.number=53673268576;

console.log(obj1);
//modify
obj.name='mervyn';
console.log(obj);
//delete
delete obj.age
console.log(obj);

let obj3={
    name: 'vijay',
    age:59,
    email:'vijay123@gmail.com',
    number:26767678,
    working:true,
    hobbies:[],
    skill:{
        frontend:['HTML','javascripts','CSS'],
        backend:'SQL'
    },
    func:function(){ //this keyword refer to current value
        console.log(`hello nanba nanbi ${this.name}`);
    }

}
//to add in array
// obj3.hobbies='cricket'
obj3.hobbies.push('pubg')
obj3.hobbies.push('cricket')
console.log(obj3);
console.log(obj3.func());







let person={
    name:'john',
    greet(){
        return(`hello world ${this.name}`);
        
    },
}
// console.log(person);

 console.log(person.greet());
 


 //using fuction constructor

 function Per(name ,age){
    this.name=name;
    this.age=age
 }
 let stu=new Per('bob',18)
 console.log(stu);


 
 //object methods
 //object.key
 //object.values
 //object.entries creates nested array 
 //object.hasownproperty to check the entries are present or not
//object.assign to combine objects  

let obj4={
    name:'pinto',
    age:26,
    gender:'male'
}
let id=Symbol("id") //symbol datatype or literals to give id screately to properties of objects
let obj5={
    empname:'shalini',
    empid:23,
    job:'HR',
    [id]:467786,
}
console.log(obj5[id]);


console.log(Object.keys(obj4));
console.log(Object.values(obj4));


console.log(Object.entries(obj5));

console.log(Object.assign (obj4,obj5));
 console.log(obj5.hasOwnProperty("age")); 
 


 